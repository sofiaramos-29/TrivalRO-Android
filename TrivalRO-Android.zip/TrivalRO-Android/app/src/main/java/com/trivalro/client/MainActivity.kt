package com.trivalro.client

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.trivalro.client.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ── Change this to your server URL ──────────────────────────────
    private val GAME_URL = "http://205.209.99.68:4000"
    // ────────────────────────────────────────────────────────────────

    private var backPressedOnce = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full immersive / fullscreen
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!isNetworkAvailable()) {
            showNoInternetDialog()
            return
        }

        setupWebView()
        setupSwipeRefresh()
        loadGame()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(false)  // disable zoom — game controls its own scale
                builtInZoomControls = false
                displayZoomControls = false

                // Performance
                setRenderPriority(WebSettings.RenderPriority.HIGH)
            }

            // Allow cookies
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(this@apply, true)
            }

            webViewClient = GameWebViewClient()
            webChromeClient = GameWebChromeClient()
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.apply {
            setColorSchemeColors(
                getColor(R.color.ro_gold),
                getColor(R.color.ro_blue)
            )
            setOnRefreshListener {
                binding.webView.reload()
            }
        }
    }

    private fun loadGame() {
        showLoading(true)
        binding.webView.loadUrl(GAME_URL)
    }

    private fun showLoading(show: Boolean) {
        binding.loadingOverlay.visibility = if (show) View.VISIBLE else View.GONE
        binding.swipeRefresh.isRefreshing = false
    }

    // ── WebViewClient ────────────────────────────────────────────────
    inner class GameWebViewClient : WebViewClient() {

        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            showLoading(true)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            showLoading(false)

            // Inject JS to optimize touch for the game
            view?.evaluateJavascript("""
                (function() {
                    document.body.style.userSelect = 'none';
                    document.body.style.webkitUserSelect = 'none';
                    document.body.style.overflow = 'hidden';
                    // Prevent context menu on long press
                    document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
                    // Prevent text selection
                    document.addEventListener('selectstart', function(e) { e.preventDefault(); });
                })();
            """.trimIndent(), null)
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            if (request?.isForMainFrame == true) {
                showLoading(false)
                showConnectionError()
            }
        }
    }

    // ── WebChromeClient ──────────────────────────────────────────────
    inner class GameWebChromeClient : WebChromeClient() {

        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
            // Suppress console spam in release
            return true
        }

        override fun onJsAlert(
            view: WebView?, url: String?, message: String?,
            result: JsResult?
        ): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("TrivalRO")
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setCancelable(false)
                .show()
            return true
        }
    }

    // ── Network ──────────────────────────────────────────────────────
    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun showNoInternetDialog() {
        AlertDialog.Builder(this)
            .setTitle("No Connection")
            .setMessage("You need an internet connection to play TrivalRO.\n\nPlease check your connection and try again.")
            .setPositiveButton("Retry") { _, _ ->
                if (isNetworkAvailable()) loadGame()
                else showNoInternetDialog()
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun showConnectionError() {
        AlertDialog.Builder(this)
            .setTitle("Connection Failed")
            .setMessage("Could not reach the TrivalRO server.\n\nThe server may be down or undergoing maintenance.")
            .setPositiveButton("Retry") { _, _ -> loadGame() }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    // ── Back button ──────────────────────────────────────────────────
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (binding.webView.canGoBack()) {
                binding.webView.goBack()
            } else {
                if (backPressedOnce) {
                    showExitDialog()
                } else {
                    backPressedOnce = true
                    Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show()
                    handler.postDelayed({ backPressedOnce = false }, 2000)
                }
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Exit Game")
            .setMessage("Are you sure you want to exit TrivalRO?")
            .setPositiveButton("Exit") { _, _ -> finish() }
            .setNegativeButton("Stay") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // ── Lifecycle ────────────────────────────────────────────────────
    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
        // Restore immersive mode
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
    }

    override fun onPause() {
        super.onPause()
        binding.webView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.webView.destroy()
        handler.removeCallbacksAndMessages(null)
    }
}
