package com.trivalro.client

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.trivalro.client.databinding.ActivitySplashBinding

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private val handler = Handler(Looper.getMainLooper())

    private val loadingMessages = listOf(
        "Connecting to Midgard...",
        "Loading world map...",
        "Summoning monsters...",
        "Preparing your adventure...",
        "Almost there, adventurer!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full immersive mode
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )

        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startLogoAnimation()
        startProgressSimulation()
    }

    private fun startLogoAnimation() {
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = 1200
            fillAfter = true
        }
        val scaleUp = ScaleAnimation(
            0.85f, 1f, 0.85f, 1f,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
            ScaleAnimation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 1200
            fillAfter = true
        }

        val animSet = AnimationSet(true).apply {
            addAnimation(fadeIn)
            addAnimation(scaleUp)
        }

        binding.logoContainer.startAnimation(animSet)
    }

    private fun startProgressSimulation() {
        val totalDuration = 3000L
        val steps = 100
        val stepDelay = totalDuration / steps
        var currentStep = 0
        var messageIndex = 0

        val runnable = object : Runnable {
            override fun run() {
                if (currentStep <= steps) {
                    binding.progressBar.progress = currentStep

                    // Update loading message at checkpoints
                    val messageAt = (steps / loadingMessages.size)
                    if (currentStep % messageAt == 0 && messageIndex < loadingMessages.size) {
                        binding.tvLoadingText.text = loadingMessages[messageIndex]
                        messageIndex++
                    }

                    currentStep++
                    handler.postDelayed(this, stepDelay)
                } else {
                    // Done loading — go to game
                    goToGame()
                }
            }
        }

        handler.postDelayed(runnable, 800L) // slight delay before starting
    }

    private fun goToGame() {
        val fadeOut = AlphaAnimation(1f, 0f).apply {
            duration = 400
            fillAfter = true
        }
        binding.root.startAnimation(fadeOut)

        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 400)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
