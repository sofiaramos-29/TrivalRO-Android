# TrivalRO Android Client

A native Android wrapper for the TrivalRO Reborn web-based game client.

## Features
- ✅ Full-screen immersive mode (no status/nav bars)
- ✅ Animated splash screen with loading progress
- ✅ Landscape-locked orientation
- ✅ Smart back button handling (double-press to exit)
- ✅ Pull-to-refresh
- ✅ No-internet detection with retry dialog
- ✅ Server error detection
- ✅ RO-themed UI (gold/dark color scheme)
- ✅ Touch optimizations injected into the game page

## Setup

### 1. Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin plugin

### 2. Clone / Open Project
Open Android Studio → File → Open → select this folder

### 3. Change the Server URL
Open `MainActivity.kt` and update line:
```kotlin
private val GAME_URL = "http://205.209.99.68:4000"
```
Replace with your server's actual URL/IP.

### 4. Build & Run
- Connect an Android device or start an emulator
- Click ▶ Run in Android Studio
- To build a release APK: Build → Generate Signed Bundle/APK

## Project Structure
```
app/src/main/
├── java/com/trivalro/client/
│   ├── SplashActivity.kt   ← Animated loading screen
│   └── MainActivity.kt     ← WebView game wrapper
├── res/
│   ├── layout/
│   │   ├── activity_splash.xml
│   │   └── activity_main.xml
│   ├── drawable/
│   │   ├── splash_gradient.xml
│   │   └── progress_bar_drawable.xml
│   └── values/
│       ├── colors.xml      ← RO color palette
│       ├── strings.xml
│       └── themes.xml
└── AndroidManifest.xml
```

## Customization
- **Server URL**: `MainActivity.kt` → `GAME_URL`
- **App name**: `strings.xml` → `app_name`
- **Colors**: `colors.xml`
- **Loading messages**: `SplashActivity.kt` → `loadingMessages` list
- **App icon**: Replace files in `mipmap-*` folders with your PNG icon
